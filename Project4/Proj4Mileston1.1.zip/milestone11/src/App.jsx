import Dtable from './components/DTable'

function App() {

  return (
    <>
      <Dtable />
    </>
  )
}

export default App
